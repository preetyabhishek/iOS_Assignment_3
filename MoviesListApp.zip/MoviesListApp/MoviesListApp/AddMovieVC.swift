//
//  AddMovieVC.swift
//  MoviesListApp
//
//  Created by mac on 06/08/22.
//

// Shivam Sharma
// ID - A00253431

// Shubham Dhamane
// ID - A00257743

import UIKit

class AddMovieVC: UIViewController
{
    @IBOutlet weak var MovieName_tf: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func btnAddMovie(_ sender: Any)
    {
        
    }
}
