//
//  MoviesTableViewCell.swift
//  MoviesListApp
//
//  Created by mac on 06/08/22.
//

// Shivam Sharma
// ID - A00253431

// Shubham Dhamane
// ID - A00257743

import UIKit

class MoviesTableViewCell: UITableViewCell
{
    @IBOutlet weak var Index_lbl: UILabel!
    @IBOutlet weak var MovieTitle_lbl: UILabel!
    @IBOutlet weak var btnDelete: UIButton!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
