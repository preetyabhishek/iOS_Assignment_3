//
//  ViewController.swift
//  MoviesListApp
//
//  Created by mac on 05/08/22.
//

// Shivam Sharma
// ID - A00253431

// Shubham Dhamane
// ID - A00257743

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var MoviesTableVw: UITableView!

    var MovieArr = ["Eternals", "Dune", "No Time To Die" ,"Last Night in Soho", "Ron’s Done Wrong", "Halloween Kills", "Venom", "Antlers", "The Addams Family 2"]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    //MARK:____________ Table View Delegates and DataSources _____________
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return MovieArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : MoviesTableViewCell = MoviesTableVw.dequeueReusableCell(withIdentifier: "MoviesCell", for: indexPath) as! MoviesTableViewCell
        
        cell.MovieTitle_lbl.text = MovieArr[indexPath.row]
        cell.Index_lbl.text = String.init(format: "%d.", indexPath.row)
        
        cell.btnDelete.tag = indexPath.row
        cell.btnDelete.addTarget(self, action: #selector(btnDeleteMovie(_:)), for: .touchUpInside)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 50
    }
    
    @objc func btnDeleteMovie(_ sender : UIButton!)
    {
        
    }
}

