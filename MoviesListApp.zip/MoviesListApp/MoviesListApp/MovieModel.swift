//
//  MovieModel.swift
//  MoviesListApp
//
//  Created by mac on 06/08/22.
//

// Shivam Sharma
// ID - A00253431

// Shubham Dhamane
// ID - A00257743

import Foundation

struct MovieModel : Codable
{
    var movieTitle : String
    var index : String
    
    func saveMovie()
    {
        
    }
    
    func deleteMovie()
    {
        
    }
    
    func toString() -> String
    {
        var output = ""
        output += self.index + "." + self.movieTitle
        return output
    }
}

